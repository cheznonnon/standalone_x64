// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ Usage ]
//
//	Init       : n_win_smallbutton_zero()
//	WM_CREATE  : n_win_smallbutton_init()
//	WM_CLOSE   : n_win_smallbutton_exit()
//	WndProc()  : n_win_smallbutton_proc()
//
//	WM_COMMAND : n_win_smallbutton_is_clicked()
//	WM_COMMAND : n_win_smallbutton_is_clicked_up()
//
//	[ Optional ]
//
//	WM_SETTINGCHANGE : n_win_smallbutton_on_settingchange()
//
//	[ Icon Resource ]
//
//	a gray-scaled icon will be a system-colored icon automatically
//	see n_win_smallbutton_bitmap() for details
//
//	[ Target Controls ]
//
//	you can use n_win_smallbutton_embed() to embed into edit controls
//
//	[ Tips ]
//
//	WS_CLIPSIBLINGS : you need to initialize a static control before a target control
//
//	Not Used        : .m and .icon is not used in main purpose
//
//	init_by_data()  : you can use a on-the-fly resource : see win32/win_combobox.c


// [!]
//
//	[ Performance ]
//
//	SS_ICON | SS_CENTERIMAGE : auto-centering   : heavy
//	SS_OWNERDRAW             : manual-centering : lightweight




#ifndef _H_NONNON_WIN32_WIN_SMALLBUTTON
#define _H_NONNON_WIN32_WIN_SMALLBUTTON




#include "../neutral/bmp/fade.c"
#include "../neutral/bmp/filter.c"
#include "../neutral/bmp/transform.c"

//#include "./gdi/doublebuffer.c"

//#include "./../game/direct2d.c"

//#include "./../game/gdiplus.c"

#include "./win.c"
#include "./gdi/bitmap.c"
#include "./gdi/color.c"
#include "./gdi/dibsection.c"




#define N_WIN_SMALLBUTTON_NAMESPACE n_posix_literal( "n_win_smallbutton" )

#define N_WIN_SMALLBUTTON_NONE    ( 0 << 0 )
#define N_WIN_SMALLBUTTON_NORMAL  ( 1 << 0 )
#define N_WIN_SMALLBUTTON_GRAYED  ( 1 << 1 )
#define N_WIN_SMALLBUTTON_HOVERED ( 1 << 2 )
#define N_WIN_SMALLBUTTON_PRESSED ( 1 << 3 )

#define N_WIN_SMALLBUTTON_CLICKED ( 100 )


typedef struct {

	n_type_gfx scale;
	n_type_gfx sx,sy;
	int        state, state_prv;

	HICON      hicon;
	n_bmp      b,m,u;
	n_bmp      bmp;

	HWND       hgui;
	WNDPROC    pfunc;

	n_bmp_fade   fade;
	u32          fade_timer;
	n_posix_bool fade_onoff;
	int          fade_showwindow;
	n_posix_bool fade_sink_onoff;

	// [!] : you can override colors

	u32        color_fg;
	u32        color_bg;
	u32        color_grayed;
	u32        color_hovered;

	// [!] : optional

	n_posix_bool dwm_transbg_onoff;

} n_win_smallbutton;

#define n_win_smallbutton_zero( p ) n_memory_zero( p, sizeof( n_win_smallbutton ) )




void
n_win_smallbutton_bitmap_make( const u8 *data, n_bmp *bmp_ret, n_type_gfx scale )
{

	n_type_gfx sx = 16;
	n_type_gfx sy = 16;

	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_1st_fast( &bmp, sx,sy );
	n_bmp_flush( &bmp, n_bmp_white );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{

		int value = data[ x + ( y * sx ) ];
		u32 color = n_bmp_rgb( value,value,value );
		n_bmp_ptr_set_fast( &bmp, x,y, color );

		x++;
		if ( x >= sx )
		{
			x = 0;
			y++;
			if ( y >= sy ) { break; }
		}
	}

	n_type_gfx size = 32 * scale;
	n_bmp_resizer( &bmp, size,size, n_bmp_white, N_BMP_RESIZER_CENTER );

	// [!] : don't use n_bmp_free_fast() : crash

	n_bmp_free( bmp_ret );
	n_bmp_new_fast( bmp_ret, size,size );
	n_bmp_flush_fastcopy( &bmp, bmp_ret );

//n_bmp_save_literal( &bmp, "ret.bmp" );
	n_bmp_free_fast( &bmp );


	return;
}

void
n_win_smallbutton_bitmap_reverse( n_win_smallbutton *p, n_bmp *bmp )
{

	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color = N_BMP_PTR( bmp )[ i ];

		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		N_BMP_PTR( bmp )[ i ] = n_bmp_rgb( r,g,b );

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

void
n_win_smallbutton_bitmap_contour( n_win_smallbutton *p, n_type_gfx o, u32 color_fg )
{

	n_bmp bmp; n_bmp_carboncopy( &p->u, &bmp );

	n_type_gfx m = p->scale * 2;
	n_type_gfx x = -m;
	n_type_gfx y = -m;
	n_posix_loop
	{

		n_bmp_rasterizer( &bmp, &p->bmp, o + x, o + y, n_bmp_white, n_posix_false );

		x++;
		if ( x > m )
		{
			x = -m;

			y++;
			if ( y > m ) { break; }
		}
	}

	n_bmp_antialias( &p->bmp, o-m,o-m, p->sx+(m*2),p->sy+(m*2), 1.0 );

	n_bmp_rasterizer( &bmp, &p->bmp, o,o, color_fg, n_posix_false );

	n_bmp_free_fast( &bmp );


	return;
}

void
n_win_smallbutton_redraw( n_win_smallbutton *p )
{

	n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );


	return;
}

void
n_win_smallbutton_bitmap( n_win_smallbutton *p )
{

	if ( p == NULL ) { return; }

	if ( n_posix_false == IsWindow( p->hgui ) ) { return; }


	n_type_gfx sx,sy; n_win_size( p->hgui, &sx, &sy );

	if ( ( sx != p->sx )||( sy != p->sy ) )
	{

		p->sx = sx;
		p->sy = sy;

		n_bmp_free( &p->u );
		n_bmp_carboncopy( &p->b, &p->u );

		n_bmp_scaler_big( &p->u, p->scale );

		n_bmp_resizer( &p->u, p->sx,p->sy, n_bmp_white, N_BMP_RESIZER_CENTER );

		n_win_smallbutton_bitmap_reverse( p, &p->u );

	}


	u32 color_fg = p->color_fg;
	u32 color_bg = p->color_bg;

	if ( p->state & N_WIN_SMALLBUTTON_GRAYED )
	{
		color_bg = p->color_grayed;
	}

	if ( p->state & N_WIN_SMALLBUTTON_HOVERED )
	{
		color_fg = p->color_hovered;
	}

	if ( p->state & N_WIN_SMALLBUTTON_PRESSED )
	{
		//
	}

	if ( p->dwm_transbg_onoff )
	{
		color_bg = 0;
	}


	n_type_gfx o = 0;
	if ( p->state & N_WIN_SMALLBUTTON_PRESSED )
	{
		if ( p->fade_sink_onoff ) { o = p->scale; }
	}


	n_posix_bool redraw = ( p->state_prv != p->state );


	n_bmp_fade_engine( &p->fade, n_win_fade_is_on() );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( p->hgui ), "%d", p->fade.percent );
	if ( p->fade.percent != 100 ) { redraw = n_posix_true; }

	n_type_real ratio = (n_type_real) p->fade.percent * 0.01;


	if ( color_fg == p->color_hovered )
	{
		color_fg = n_bmp_blend_pixel( p->color_fg     , color_fg, ratio );
	} else {
		color_fg = n_bmp_blend_pixel( p->color_hovered, color_fg, ratio );
	}

	if ( p->fade_onoff )
	{
		if ( p->state & N_WIN_SMALLBUTTON_HOVERED )
		{
			color_fg = p->color_hovered;
		} else {
			color_fg = p->color_fg;
		}
	}


	n_bmp_free( &p->bmp );
	n_bmp_new_fast( &p->bmp, p->sx,p->sy );
	n_bmp_flush( &p->bmp, color_bg );

	n_win_smallbutton_bitmap_contour( p, o, color_fg );


	if ( p->fade_onoff )
	{
		if ( p->fade_showwindow == SW_HIDE   )
		{
			n_bmp_flush_mixer( &p->bmp, color_bg,       ratio );
			redraw = n_posix_true;
		} else
		if ( p->fade_showwindow == SW_NORMAL )
		{
			n_bmp_flush_mixer( &p->bmp, color_bg, 1.0 - ratio );
			redraw = n_posix_true;
		}
	}


	//if ( ( p->dwm_transbg_onoff == n_posix_false )&&( n_win_dwm_is_on() ) ) { n_bmp_alpha_visible( &p->bmp ); }
//n_bmp_save_literal( &p->bmp, "ret.bmp" );
//n_bmp_save_literal( &p->u, "u.bmp" );

//redraw = n_posix_true;
	if ( redraw )
	{
		//n_win_refresh( p->hgui, n_posix_false );
		n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );
	}


	p->state_prv = p->state;


	return;
}

void
n_win_smallbutton_embed( n_win_smallbutton *p, HWND hwnd_edit, n_type_int index, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }

	if ( n_posix_false == IsWindow( p->hgui   ) ) { return; }
	if ( n_posix_false == IsWindow( hwnd_edit ) ) { return; }


	index = n_posix_max( 1, index + 1 );

	n_type_gfx ix,iy,isx,isy; n_win_location( hwnd_edit, &ix,&iy,&isx,&isy );

	{

		const n_type_gfx border = 2;

		n_type_gfx btn = isy - ( border * 2 );
		n_type_gfx bx  = bx = ( ix + isx ) - border - ( btn * index );
		n_type_gfx by  = iy + border;

		n_win_move_simple( p->hgui, bx,by, btn,btn, redraw );
		if ( redraw ) { n_win_smallbutton_bitmap( p ); }

		n_win_edit_margin_set( hwnd_edit, 0, btn * index );

	}


	return;
}

void
n_win_smallbutton_onoff( n_win_smallbutton *p, n_posix_bool onoff, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }

	if ( onoff )
	{
		p->state &= ~N_WIN_SMALLBUTTON_GRAYED;
	} else {
		p->state |=  N_WIN_SMALLBUTTON_GRAYED;
	}

	if ( redraw )
	{
		n_win_smallbutton_bitmap( p );
	}


	return;
}

void
n_win_smallbutton_press( n_win_smallbutton *p, n_posix_bool onoff )
{

	if ( p == NULL ) { return; }

	if ( onoff )
	{
		p->state |=  N_WIN_SMALLBUTTON_PRESSED;
	} else {
		p->state &= ~N_WIN_SMALLBUTTON_PRESSED;
	}

	n_win_smallbutton_bitmap( p );


	return;
}

void
n_win_smallbutton_hover( n_win_smallbutton *p, n_posix_bool onoff )
{

	if ( p == NULL ) { return; }


	if ( onoff )
	{
		p->state |=  N_WIN_SMALLBUTTON_HOVERED;
	} else {
		p->state &= ~N_WIN_SMALLBUTTON_HOVERED;
	}


//n_win_smallbutton_bitmap( p ); return;


	if ( p->state == p->state_prv ) { return; }

	if ( p->fade.stop == n_posix_false ) { return; }


	n_bmp_fade_init( &p->fade, n_bmp_black );
	n_bmp_fade_go  ( &p->fade, n_bmp_white );

	if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hgui, p->fade_timer, 33 );


	return;
}

void
n_win_smallbutton_show( n_win_smallbutton *p, int sw )
{

	if ( n_posix_false == n_win_fade_is_on() )
	{
		ShowWindow( p->hgui, sw );
		return;
	}


	if ( p->fade_showwindow == sw )
	{
		if (   p->fade_onoff ) { return; }
		if ( sw == SW_NORMAL ) { ShowWindow( p->hgui, SW_NORMAL ); return; }
	}


	p->fade_onoff      = n_posix_true;
	p->fade_showwindow = sw;

	if ( p->fade_showwindow == SW_NORMAL )
	{
		ShowWindow( p->hgui, p->fade_showwindow );
	}

	n_bmp_fade_init( &p->fade, n_bmp_black );
	n_bmp_fade_go  ( &p->fade, n_bmp_white );

	if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( p->hgui, p->fade_timer, 33 );


	return;
}

n_posix_bool
n_win_smallbutton_is_clicked( WPARAM wparam )
{

	n_posix_bool ret = n_posix_false;


	int code = HIWORD( wparam );

	if (
		( STN_CLICKED == code )
		||
		( STN_DBLCLK  == code )
	)
	{
		ret = n_posix_true;
	}


	return ret;
}

n_posix_bool
n_win_smallbutton_is_clicked_up( WPARAM wparam )
{

	n_posix_bool ret = n_posix_false;


	int code = HIWORD( wparam );

	if ( N_WIN_SMALLBUTTON_CLICKED == code ) { return n_posix_true; }


	return ret;
}

n_posix_bool
n_win_smallbutton_is_doubleclicked( WPARAM wparam )
{

	n_posix_bool ret = n_posix_false;


	int code = HIWORD( wparam );

	if ( STN_DBLCLK == code )
	{
		ret = n_posix_true;
	}


	return ret;
}

LRESULT CALLBACK
#ifdef _WIN64
n_win_smallbutton_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_smallbutton_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{
#ifdef _WIN64
	n_win_smallbutton *p = (void*) dwRefData;
	if ( p == NULL ) { return 0; }
#else  // #ifdef _WIN64
	n_win_smallbutton *p = (void*) n_win_property_get( hwnd, N_WIN_SMALLBUTTON_NAMESPACE );
	if ( p == NULL ) { return 0; }
#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == p->fade_timer )
		{

			n_win_smallbutton_bitmap( p );

			if ( p->fade.percent == 100 )
			{
				n_win_timer_exit( p->hgui, p->fade_timer );

				if ( p->fade_onoff )
				{
					p->fade_onoff = n_posix_false;
					if ( p->fade_showwindow == SW_HIDE )
					{
						ShowWindow( p->hgui, p->fade_showwindow );
					}
				}
			}

		}

	break;


	case WM_SHOWWINDOW :

		if ( wparam )
		{
			if ( p->fade_onoff )
			{
				u32 color_bg = p->color_bg;
				if ( p->dwm_transbg_onoff ) { color_bg = 0; }

				n_bmp_free( &p->bmp );
				n_bmp_new_fast( &p->bmp, p->sx,p->sy );
				n_bmp_flush( &p->bmp, color_bg );

				return 0;
			}
		}

	break;


	case WM_MOUSEMOVE :

		n_win_on_mousemove( hwnd );

	break;

	case WM_MOUSEHOVER :
//n_win_hwndprintf_literal( GetParent( hwnd ), " WM_MOUSEHOVER " );

		n_win_smallbutton_hover( p, n_posix_true );

	break;

	case WM_MOUSELEAVE :
//n_win_hwndprintf_literal( GetParent( hwnd ), " WM_MOUSELEAVE " );

		n_win_smallbutton_hover( p, n_posix_false );
		n_win_smallbutton_press( p, n_posix_false );

	break;

	case WM_LBUTTONDOWN   :
	case WM_LBUTTONDBLCLK :

		// [!] : WM_MOUSELEAVE will never come when captured
		//SetCapture( hwnd );

		n_win_smallbutton_press( p, n_posix_true );

	break;

	case WM_LBUTTONUP :

		//ReleaseCapture();

		n_win_smallbutton_press( p, n_posix_false );

		n_win_message_send( GetParent( hwnd ), WM_COMMAND, n_win_param_hilo( N_WIN_SMALLBUTTON_CLICKED, 0 ), hwnd );

	break;
/*
	case WM_MBUTTONUP :

		n_win_smallbutton_show( p, SW_HIDE );

	break;
*/

	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( p->pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

#define n_win_smallbutton_on_settingchange(         p, h, i ) n_win_smallbutton_on_settingchange_internal( p, h, i, NULL )
#define n_win_smallbutton_on_settingchange_by_data( p, h, d ) n_win_smallbutton_on_settingchange_internal( p, h, 0,    d )

void
n_win_smallbutton_on_settingchange_internal( n_win_smallbutton *p, HWND hgui, n_type_int index, const u8 *data )
{

	// Resource

	p->scale = trunc( n_win_scale( hgui ) );

	n_win_stdsize_icon_large( &p->sx, &p->sy );

	if ( data == NULL )
	{
		p->hicon = n_win_icon_init( NULL, index, N_WIN_ICON_INIT_OPTION_RESOURCE );
		n_win_icon_hicon2bmp_1st( p->hicon, p->sx,p->sy, &p->b, &p->m );

		// [x] : High-DPI : Patch
		n_bmp_fill( &p->b, 0,0, n_bmp_white );
	} else {
		n_win_smallbutton_bitmap_make( data, &p->b, p->scale );
//n_bmp_free( &p->b );
//n_bmp_new( &p->b, 32,32 );
	}


	// [!] : default colors

	if ( ( n_win_darkmode_onoff )||( n_win_color_is_highcontrast() ) )
	{
		p->color_bg      = n_win_darkmode_systemcolor_colorref2argb( COLOR_WINDOW     );
		p->color_fg      = n_bmp_rgb( 111,111,111 );
		p->color_grayed  = n_bmp_blend_pixel( p->color_fg, p->color_bg, 0.75 );
		p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT );
		p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 255, 128 );
	} else {
		p->color_bg      = n_gdi_systemcolor( COLOR_WINDOW    );
		p->color_fg      = n_gdi_systemcolor( COLOR_GRAYTEXT  );
		p->color_grayed  = n_gdi_systemcolor( COLOR_BTNFACE   );
		p->color_hovered = n_gdi_systemcolor( COLOR_HIGHLIGHT );
		p->color_hovered = n_bmp_hsl_replace_pixel( p->color_hovered, -1, 255, 128 );
	}


	n_bmp_carboncopy( &p->b, &p->u );


	n_win_smallbutton_bitmap( p );


	return;
}

#define n_win_smallbutton_init(         p, h, i ) n_win_smallbutton_init_internal( p, h, i, NULL )
#define n_win_smallbutton_init_by_data( p, h, d ) n_win_smallbutton_init_internal( p, h, 0,    d )

void
n_win_smallbutton_init_internal( n_win_smallbutton *p, HWND hgui, n_type_gfx index, const u8 *data )
{

	n_win_smallbutton_on_settingchange_internal( p, hgui, index, data );


	// UI

	p->hgui = hgui;


#ifdef _WIN64
	SetWindowSubclass( p->hgui, n_win_smallbutton_subclass, 0, (DWORD_PTR) p );
#else  // #ifdef _WIN64
	p->pfunc = (WNDPROC) n_win_gui_subclass_set( p->hgui, n_win_smallbutton_subclass );
	n_win_property_init( p->hgui, N_WIN_SMALLBUTTON_NAMESPACE, (int) p );
#endif // #ifdef _WIN64


	n_win_style_add( p->hgui, SS_NOTIFY );


	p->fade_sink_onoff = n_posix_true;


	return;
}

void
n_win_smallbutton_exit( n_win_smallbutton *p )
{

	// UI

#ifdef _WIN64
	RemoveWindowSubclass( p->hgui, n_win_smallbutton_subclass, 0 );
#else  // #ifdef _WIN64
	n_win_gui_subclass_set( p->hgui, p->pfunc );
	n_win_property_exit( p->hgui, N_WIN_SMALLBUTTON_NAMESPACE );
#endif // #ifdef _WIN64


	// Resource

	n_win_icon_exit( p->hicon );

	n_bmp_free( &p->b   );
	n_bmp_free( &p->m   );
	n_bmp_free( &p->u   );
	n_bmp_free( &p->bmp );


	// Cleanup

	DestroyWindow( p->hgui );

	n_win_smallbutton_zero( p );


	return;
}

void
n_win_smallbutton_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_smallbutton *p )
{

	if ( p == NULL ) { return; }


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( p->hgui != di->hwndItem ) { break; }


		// [ Mechanism ]
		//
		//	[ BS_OWNERDRAW ]
		//
		//	focus will be moved
		//
		//	base     : ODS_NOACCEL(0x100) | ODS_NOFOCUSRECT(0x200)
		//	clicked  : ODS_FOCUS(0x0010) | ODS_SELECTED(0x0001)
		//	released : ODS_FOCUS(0x0010)

//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), "%d : %d", di->itemAction, di->itemState );

//n_bmp_flush( &p->bmp, n_bmp_black );

		if ( n_posix_false )//( p->dwm_transbg_onoff )
		{
/*
			HBITMAP hbmp;
			n_bmp   nbmp;

			n_gdi_dibsection_zero( &hbmp, &nbmp );
			n_gdi_dibsection_init( &hbmp, &nbmp, p->hgui, NULL, p->sx, p->sy );

			n_bmp_flush( &nbmp, 0 );


			n_bmp bmp_base; n_bmp_carboncopy( &p->bmp, &bmp_base );

			n_type_gfx sx = N_BMP_SX( &bmp_base );
			n_type_gfx sy = N_BMP_SX( &bmp_base );

			n_type_gfx x = 0;
			n_type_gfx y = 0;
			n_posix_loop
			{break;

				u32 clr; n_bmp_ptr_get( &bmp_base, x,y, &clr );

				if ( clr != 0 )
				{
					n_bmp_ptr_set( &bmp_base, x,y, n_bmp_argb( 64,255,255,255 ) );
				}

				x++;
				if ( x >= sx )
				{
					x = 0;

					y++;
					if ( y >= sy ) { break; }
				}
			}

			n_bmp_flush( &nbmp, 0 );

			n_type_gfx scale = trunc( n_win_scale( p->hgui ) );

			x = -scale;
			y = -scale;
			n_posix_loop
			{break;

				if ( ( x == 0 )&&( y == 0 ) )
				{
					//
				} else {
					n_bmp_transcopy( &bmp_base, &nbmp, 0,0,sx,sy, x,y );
				}

				x++;
				if ( x > scale )
				{
					x = -scale;

					y++;
					if ( y > scale ) { break; }
				}
			}

			n_bmp_flush_transcopy( &p->bmp, &nbmp );
//n_bmp_save_literal( &nbmp, "ret.bmp" );
//n_bmp_save_literal( &bmp_base, "ret.bmp" );

			n_gdi_bitmap_draw( p->hgui, &nbmp, 0,0,p->sx,p->sy, 0,0 );
*/
/*
			// [x] : very heavy : unuseable

			n_gdi_doublebuffer db; n_gdi_doublebuffer_zero( &db );
			n_gdi_doublebuffer_init_direct2d( &db, p->hgui, p->sx,p->sy, n_posix_true );

			if ( db.bpp == 32 )
			{
				n_bmp_flush_mirror( &nbmp, N_BMP_MIRROR_UPSIDE_DOWN );
				n_bmp_flush_fastcopy( &nbmp, &db.bmp );
				n_gdi_doublebuffer_exit( &db );
			} else {
				n_gdi_doublebuffer_cleanup( &db );
				n_gdi_bitmap_draw( p->hgui, &nbmp, 0,0,p->sx,p->sy, 0,0 );
			}
*/
/*
			// [x] : very heavy too : unuseable

			n_direct2d_init();

			if ( n_direct2d_is_on() )
			{
				n_direct2d_make( p->hgui, N_BMP_PTR( &nbmp ), p->sx,p->sy );
				n_direct2d_copy( p->hgui, N_BMP_PTR( &nbmp ), p->sx,p->sy, 0,0 );
				n_direct2d_draw( p->hgui, 0,0, p->sx,p->sy );
				n_direct2d_exit();
			} else {
				n_gdi_bitmap_draw( p->hgui, &nbmp, 0,0,p->sx,p->sy, 0,0 );
			}
*/
/*
			// [x] : flicker

			n_gdiplus_init();

			if ( n_gdiplus_is_on() )
			{
				n_gdiplus_draw( di->hDC, N_BMP_PTR( &nbmp ), p->sx,p->sy );
			} else {
				n_gdi_bitmap_draw( p->hgui, &nbmp, 0,0,p->sx,p->sy, 0,0 );
			}

			n_gdiplus_exit();
*/
/*
			n_bmp_free( &bmp_base );

			n_gdi_dibsection_exit( &hbmp, &nbmp );
*/
		} else {
//n_bmp_save_literal( &p->bmp, "ret.bmp" );

			n_gdi_bitmap_draw( p->hgui, &p->bmp, 0,0,p->sx,p->sy, 0,0 );

		}

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SMALLBUTTON


