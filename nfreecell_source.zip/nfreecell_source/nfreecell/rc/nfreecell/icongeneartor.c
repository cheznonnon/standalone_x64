



#include "../../../nonnon/neutral/bmp/all.c"
#include "../../../nonnon/neutral/curico.c"

#include "../../../nonnon/win32/win.c"




void
n_freecell_icongenerator( const n_posix_char *name_neko, const n_posix_char *name_icon )
{

	// Phase 1

	n_bmp neko;
	n_bmp_zero( &neko );
	n_bmp_load( &neko, name_neko );

	s32 sx = N_BMP_SX( &neko );
	s32 sy = N_BMP_SY( &neko );


	// Phase 2

	const u32 fg_blk = n_bmp_rgb( 150,  0,100 );
	const u32 bg_blk = n_bmp_rgb( 255,  0,200 );


	n_bmp icon;
	n_bmp_zero( &icon );
	n_bmp_1st( &icon, sx,sy );
	n_bmp_flush_gradient( &icon, fg_blk, bg_blk, N_BMP_GRADIENT_CIRCLE | N_BMP_GRADIENT_CENTERING );

	n_bmp_flush_reducer( &icon, 4 );


	// Phase 3

	n_bmp_flush_transcopy( &neko, &icon );

	n_bmp_fill( &icon, 0,0, n_bmp_trans );
	n_bmp_alpha_visible( &icon );

	{

		n_curico curico;
		n_curico_zero( &curico );

		n_curico_save( &curico, &icon, name_icon );

	}


	n_bmp_free( &neko );
	n_bmp_free( &icon );


	return;
}

int
main( void )
{

	n_posix_char *neko_32 = n_posix_literal( "./mask_001.bmp" );
	n_posix_char *neko_48 = n_posix_literal( "./mask_002.bmp" );
	//n_posix_char *neko_64 = n_posix_literal( "./mask_003.bmp" );
	n_posix_char *icon_32 = n_posix_literal( "./001.ico" );
	n_posix_char *icon_48 = n_posix_literal( "./002.ico" );
	//n_posix_char *icon_64 = n_posix_literal( "./003.ico" );


	n_freecell_icongenerator( neko_32, icon_32 );
	n_freecell_icongenerator( neko_48, icon_48 );
	//n_freecell_icongenerator( neko_64, icon_64 );


	return 0;
}

