


#import <Cocoa/Cocoa.h>




@interface NonnonNSImageView : NSImageView <NSDraggingDestination>
@end

@implementation NonnonNSImageView

-(id)initWithFrame:(NSRect) frame
{
    
    self = [super initWithFrame:frame];
    
    if ( self )
    {
        [self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypePNG]];
        NSLog( @"initWithFrame" );
    }
    
    return self;
}

-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
NSLog( @"draggingEntered" );
    return NSDragOperationEvery;
}

-(void) draggingExited:(id<NSDraggingInfo>)sender
{
NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:(id<NSDraggingInfo>)sender
{
NSLog( @"prepareForDragOperation" );

    return YES;
}

-(BOOL) performDragOperation:(id<NSDraggingInfo>)sender
{
NSLog( @"performDragOperation" );
    return YES;
}

-(void) concludeDragOperation:(id<NSDraggingInfo>)sender
{
NSLog( @"concludeDragOperation" );
    //
}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
NSLog( @"draggingUpdated" );
    return NSDragOperationEvery;
}

@end
