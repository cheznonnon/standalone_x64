// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_OBJECT_STRING_PATH
#define _H_NONNON_NEUTRAL_OBJECT_STRING_PATH




#include "../object.c"
#include "../string_path.c"


#include "./string.c"




#ifdef N_OBJECT_DEBUG

n_posix_bool n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG




n_posix_char*
N_OBJECT_STRING_PATH_PTR( const n_object *p )
{

	if ( n_object_error( p ) ) { return NULL; }

	return (n_posix_char*) N_OBJECT_PTR( p );
}




n_type_int
n_object_string_path_cch( const n_object *p )
{

	if ( n_object_error( p ) ) { return 0; }


#ifdef N_OBJECT_DEBUG

	if ( n_object_string_path_suppress == n_posix_false )
	{
		n_object_name = n_posix_literal( "n_object_string_path_cch()" );
	}

#endif // #ifdef N_OBJECT_DEBUG


	n_type_int i = 0;
	n_posix_loop
	{

		if ( n_object_is_accessible( p, i + 1 ) )
		{

			if (
				( N_OBJECT_STRING_PATH_PTR( p )[ i + 0 ] == N_STRING_CHAR_NUL )
				&&
				( N_OBJECT_STRING_PATH_PTR( p )[ i + 1 ] == N_STRING_CHAR_NUL )
			)
			{
				i++;
				break;
			}

		} else {

			i = 0;

			break;

		}

		i++;

	}


	return i;
}

void
n_object_string_path_terminate( n_object *p, n_type_int index )
{

	if ( n_object_error( p ) ) { return; }


#ifdef N_OBJECT_DEBUG

	if ( n_object_string_path_suppress == n_posix_false )
	{
		n_object_name = n_posix_literal( "n_object_string_path_terminate()" );
	}

#endif // #ifdef N_OBJECT_DEBUG


	if ( n_object_is_accessible( p, index + 1 ) )
	{
		N_OBJECT_STRING_PATH_PTR( p )[ index + 0 ] = N_STRING_CHAR_NUL;
		N_OBJECT_STRING_PATH_PTR( p )[ index + 1 ] = N_STRING_CHAR_NUL;
	}


	return;
}

n_type_int
n_object_string_path_copy( const n_object *f, n_object *t )
{

	if ( n_object_error( f ) ) { return 0; }
	if ( n_object_error( t ) ) { return 0; }

	if ( f->count > t->count ) { return 0; }

	n_posix_char *str_f = N_OBJECT_STRING_PATH_PTR( f );
	n_posix_char *str_t = N_OBJECT_STRING_PATH_PTR( t );


	return n_posix_sprintf_literal( str_t, "%s", str_f );
}

n_posix_bool
n_object_string_path_slash_check( const n_object *p, n_type_int index )
{

	if ( n_object_string_is_empty( p ) ) { return n_posix_false; }


#ifdef N_OBJECT_DEBUG

	if ( n_object_string_path_suppress == n_posix_false )
	{
		n_object_name = n_posix_literal( "n_object_string_path_slash_check()" );
	}

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_POSIX_PLATFORM_WINDOWS


	n_posix_char *str = N_OBJECT_STRING_PATH_PTR( p );

	n_type_int i = 0;
	n_posix_loop
	{
		if ( i >= index ) { break; }

		if ( n_object_is_accessible( p, i ) )
		{
			i += n_string_doublebyte_increment( str[ i ] );
		}
	}
//n_posix_debug_literal( "%d %d", i, index );

	if ( i != index ) { return n_posix_false; }

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS

	if ( n_object_is_accessible( p, index ) )
	{
		if ( str[ index ] == N_POSIX_CHAR_SLASH ) { return n_posix_true; }
	}


	return n_posix_false;
}

n_posix_bool
n_object_string_path_is_abspath( const n_object *p )
{

	if ( n_object_string_is_empty( p ) ) { return n_posix_false; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_is_abspath()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_POSIX_PLATFORM_WINDOWS

	// [!] : don't use n_posix_strlen() for performance

	n_posix_char *path = N_OBJECT_STRING_PATH_PTR( p );

	if (
		( n_object_is_accessible( p, 1 ) )
		&&
		(
			( path[ 0 ] != N_STRING_CHAR_NUL )
			&&
			( n_string_is_alphabet( path, 0 ) )
		)
		&&
		(
			( path[ 1 ] != N_STRING_CHAR_NUL )
			&&
			( path[ 1 ] == N_STRING_CHAR_COLON )
		)
	)
	{
		return n_posix_true;
	}

#else

	if ( n_object_string_path_slash_check( p, 0 ) ) { return n_posix_true; }

#endif


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return n_posix_false;
}

n_posix_bool
n_object_string_path_is_drivename( const n_object *p )
{

	if ( n_object_error( p ) ) { return n_posix_false; }


	return n_posix_is_drivename( p->ptr );
}

#define n_object_string_path_drivename_slash_add( p ) n_object_string_path_drivename_slash_set( p, n_posix_true  )
#define n_object_string_path_drivename_slash_del( p ) n_object_string_path_drivename_slash_set( p, n_posix_false )

// internal
void
n_object_string_path_drivename_slash_set( n_object *p, n_posix_bool is_add )
{

	if ( n_object_string_is_empty( p ) ) { return; }


	if ( n_posix_false == n_object_string_path_is_drivename( p ) ) { return; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_drivename_slash_set()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	n_posix_char *path = N_OBJECT_STRING_PATH_PTR( p );

	n_type_int cch = n_posix_strlen( path );

	if ( is_add )
	{

		if ( n_posix_false == n_object_string_path_slash_check( p, cch - 1 ) )
		{
			n_posix_strcat( path, N_POSIX_SLASH );
			n_object_string_path_terminate( p, cch + 1 );
		}

	} else {

		if ( n_posix_false != n_object_string_path_slash_check( p, cch - 1 ) )
		{
			n_object_string_path_terminate( p, cch - 1 );
		}

	}


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return;
}

#define n_object_string_path_free( p ) n_object_free( p )

#define n_object_string_path_new(      cch ) n_object_string_path_new_internal( cch, n_posix_false )
#define n_object_string_path_new_fast( cch ) n_object_string_path_new_internal( cch, n_posix_true  )

n_object*
n_object_string_path_new_internal( n_type_int cch, n_posix_bool is_fast )
{
//return NULL;

	// [!] : you need to n_object_string_path_free() a returned variable


	// [!] : +2 for double NUL('\0')

	n_object *p = n_object_new( cch + 2, sizeof( n_posix_char ), n_posix_false );

	if ( is_fast )
	{
		n_object_string_path_terminate( p, 0 );
	} else {
		n_memory_zero( p->ptr, p->byte );
	}


	return p;
}

n_object*
n_object_string_path_carboncopy( const n_object *p )
{
//return NULL;

	// [!] : you need to n_object_string_path_free() a returned variable


	n_posix_char *str = NULL;
	if ( n_object_error( p ) )
	{
		//
	} else {
		str = N_OBJECT_STRING_PATH_PTR( p );
	}


	n_type_int cch;

	if ( str == NULL )
	{
		cch = 0;
	} else {
		cch = p->count;
	}


	// [!] : +2 for double NUL('\0')

	n_object *p_ret = n_object_new( cch + 2, sizeof( n_posix_char ), n_posix_false );


	if ( str == NULL )
	{
		n_memory_zero( p_ret->ptr, p_ret->byte );
	} else {
		n_object_string_path_copy( p, p_ret );
	}


	return p_ret;
}

#define n_object_string_path_set_literal( str ) n_object_string_path_set( n_posix_literal( str ) )

n_object*
n_object_string_path_set( const n_posix_char *str )
{

	if ( n_string_is_empty( str ) ) { return NULL; }


	n_type_int  cch = n_string_path_cch( str );
	n_object   *ret = n_object_string_path_new( cch );

	n_string_path_copy( str, N_OBJECT_STRING_PATH_PTR( ret ) );


	return ret;
}

n_object*
n_object_string_path_cat( n_object *first, ... )
{

	// [Mechanims]
	//
	//	the last parameter needs to be NULL
	//	this might be a GCC's bug


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_cat()" );

#endif // #ifdef N_OBJECT_DEBUG


	n_type_int cch = 0;


	n_object *p;


	{

		p = NULL;

		va_list vl; va_start( vl, first );

		n_posix_loop
		{

			if ( p == NULL )
			{
				p = first;
			} else {
				p = va_arg( vl, n_object* );
				if ( p == NULL ) { break; }
			}
//n_posix_debug_literal( "%s", str );
			cch += p->count;

		}

		va_end( vl );

	}
//n_posix_debug_literal( "%d", cch );


	n_object *ret = n_object_string_path_new( cch );

	{

		p = NULL;

		va_list vl; va_start( vl, first );

		n_type_int i = 0;
		n_posix_loop
		{

			if ( p == NULL )
			{
				p = first;
			} else {
				p = va_arg( vl, n_object* );
				if ( p == NULL ) { break; }
			}

			n_posix_char *s = N_OBJECT_STRING_PATH_PTR( p );

			n_type_int cch = n_posix_strlen( s );
			if ( n_object_is_accessible( ret, i + cch ) )
			{
				i += n_posix_sprintf_literal( &N_OBJECT_STRING_PATH_PTR( ret )[ i ], "%s", s );
			}

		}

		va_end( vl );

	}


	return ret;
}

n_object*
n_object_string_path_slash_new( const n_object *path )
{

	// [!] : you need to n_object_string_path_free() a returned variable


	if ( n_object_string_is_empty( path ) ) { return NULL; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_slash_new()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

	n_type_int cch = 1;
	if ( n_posix_false == n_object_string_is_empty( path ) ) { cch += path->count; }

	n_object *ret = n_object_string_path_new( cch );

	n_object_string_path_copy( path, ret );
	n_object_string_path_drivename_slash_add( ret );


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return ret;
}

n_type_int
n_object_string_path_multiple_cch( const n_object *path, n_type_int index )
{

	// [ Mechanism ]
	//
	//	"C:\\path1\0C:\\path2\0\0"


	if ( n_object_string_is_empty( path ) ) { return 0; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_multiple_cch()" );

#endif // #ifdef N_OBJECT_DEBUG


	n_type_int count = 0;


	const n_posix_char *str = N_OBJECT_STRING_PATH_PTR( path );

	n_type_int i = 0;
	n_type_int j = 0;
	n_posix_loop
	{

		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( count == index )
		{
			j++;
		}

		i++;

		n_object_is_accessible( path, i );

		if ( str[ i ] == N_STRING_CHAR_NUL ) { count++; i++; }

		n_object_is_accessible( path, i );

	}


	return j;
}

#define n_object_string_path_multiple_count( p ) n_object_string_path_multiple_internal( p, 0, NULL, n_posix_true )

#define n_object_string_path_multiple( p, i, ret ) n_object_string_path_multiple_internal( p, i, ret, n_posix_false )

n_type_int
n_object_string_path_multiple_internal( const n_object *path, n_type_int index, n_object *ret, n_posix_bool is_count )
{

	// [ Mechanism ]
	//
	//	"C:\\path1\0C:\\path2\0\0"


	if ( n_object_string_is_empty( path ) ) { return 0; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_multiple_internal()" );

#endif // #ifdef N_OBJECT_DEBUG


	const n_posix_char *str = N_OBJECT_STRING_PATH_PTR( path );


	n_type_int count = 0;


	n_type_int i = 0;
	n_type_int j = 0;
	n_posix_loop
	{
		if ( str[ i ] == N_STRING_CHAR_NUL ) { break; }

		if ( ( is_count == n_posix_false )&&( count == index ) )
		{
			if ( ret != NULL )
			{
				if (
					( n_object_is_accessible( path, i ) )
					&&
					( n_object_is_accessible(  ret, j ) )
				)
				{
					N_OBJECT_STRING_PATH_PTR( ret )[ j ] = str[ i ]; j++;

					n_object_string_path_terminate( ret, j );
				}
			}
		}

		i++;
		if ( str[ i ] == N_STRING_CHAR_NUL ) { count++; i++; }

	}


	return count;
}

n_object*
n_object_string_path_multiple_new( const n_object *p, n_type_int index )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_multiple_cch( p, index );
	n_object   *ret = n_object_string_path_new( cch );


	n_object_string_path_multiple( p, index, ret );


	return ret;
}

n_type_int
n_object_string_path_make_cch( const n_object *dir, const n_object *file )
{

	if ( n_object_error( dir  ) ) { return 0; }
	if ( n_object_error( file ) ) { return 0; }


	// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

	return dir->count + 1 + file->count;
}

void
n_object_string_path_make( const n_object *dir, const n_object *file, n_object *ret )
{

	if ( ret == NULL ) { return; }


	if ( n_object_string_is_empty( dir  ) ) { return; }
	if ( n_object_string_is_empty( file ) ) { return; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_make()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	n_object *tmp_dir  = n_object_string_path_carboncopy( dir  );
	n_object *tmp_file = n_object_string_path_carboncopy( file );


	// [!] : "C:\" => "C:" if needed

	n_object_string_path_drivename_slash_del( tmp_dir );


	// [!] : "\file" => "file"

	n_type_int skip = 0;
	if ( n_object_string_path_slash_check( tmp_file, 0 ) )
	{
		skip = 1;
	}


	n_type_int cch = n_posix_sprintf_literal
	(
		 N_OBJECT_STRING_PATH_PTR( ret ),
		 "%s%s%s",
		 N_OBJECT_STRING_PATH_PTR( tmp_dir  ),
		 N_POSIX_SLASH,
		&N_OBJECT_STRING_PATH_PTR( tmp_file )[ skip ]
	);

	n_object_string_path_terminate( ret, cch );


	n_object_string_path_free( &tmp_dir  );
	n_object_string_path_free( &tmp_file );


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return;
}

n_object*
n_object_string_path_make_new( const n_object *dir, const n_object *file )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_make_cch( dir, file );
	n_object   *ret = n_object_string_path_new( cch );

	n_object_string_path_make( dir, file, ret );


	return ret;
}

n_type_int
n_object_string_path_split_cch( const n_object *path, n_type_int index )
{

	// [!] : not a path name

	if ( n_posix_false == n_object_string_path_is_abspath( path ) ) { return 0; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_split_cch()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	// [!] : "C:\" => "C:" if needed

	n_object *tmp_path = n_object_string_path_carboncopy( path );

	n_object_string_path_drivename_slash_del( tmp_path );


	n_type_int  i = 0;
	n_type_int ii = 0;
	n_type_int  n = 0;
	n_posix_loop
	{

		if ( index == n )
		{
			ii++;
		}


		i++;
		if ( N_OBJECT_STRING_PATH_PTR( tmp_path )[ i ] == N_STRING_CHAR_NUL ) { break; }


		if ( n_object_string_path_slash_check( tmp_path, i ) )
		{

			n++;

			i++;
			if ( N_OBJECT_STRING_PATH_PTR( tmp_path )[ i ] == N_STRING_CHAR_NUL ) { break; }
		}
	}


	n_object_string_path_free( &tmp_path );


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return ii;
}

#define n_object_string_path_split_count( path ) n_object_string_path_split( path, NULL, 0 )

n_type_int
n_object_string_path_split( const n_object *path, n_object *ret, n_type_int index )
{

	// [!] : this module is based on n_path_divider()

	// [!] : Return Value
	//
	//	ret == 0 : no index
	//	ret >= 1 : index count


	// [!] : not a path name

	if ( n_posix_false == n_object_string_path_is_abspath( path ) ) { return 0; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_split()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	// [!] : "C:\" => "C:" if needed

	n_object *tmp_path = n_object_string_path_carboncopy( path );

	n_object_string_path_drivename_slash_del( tmp_path );


	n_type_int  i = 0;
	n_type_int ii = 0;
	n_type_int  n = 0;
	n_posix_loop
	{//break;

		n_posix_char *s = N_OBJECT_STRING_PATH_PTR( tmp_path );

		if ( index == n )
		{
			if (
				( n_object_is_accessible( ret     , ii ) )
				&&
				( n_object_is_accessible( tmp_path,  i ) )
			)
			{
				N_OBJECT_STRING_PATH_PTR( ret )[ ii ] = s[ i ];
			}

			ii++;

			n_object_string_path_terminate( ret, ii );
		}


		i++;
		if ( s[ i ] == N_STRING_CHAR_NUL ) { break; }


		if ( n_object_string_path_slash_check( tmp_path, i ) )
		{

			n++;

			i++;
			if ( s[ i ] == N_STRING_CHAR_NUL ) { break; }
		}
	}


	n_object_string_path_free( &tmp_path );


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return ( 1 + n );
}

n_object*
n_object_string_path_split_new( const n_object *path, n_type_int index )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_split_cch( path, index );
	n_object   *pth = n_object_string_path_new_fast( cch );


	n_object_string_path_split( path, pth, index );


	return pth;
}

n_type_int
n_object_string_path_name_cch( const n_object *path )
{

	n_type_int cch = 0;


	n_type_int count = n_object_string_path_split( path, NULL, 0 );
	if ( count == 0 )
	{
		cch = path->count;
	} else {
		cch = n_object_string_path_split_cch( path, count - 1 );
	}


	return cch;
}

// internal
void
n_object_string_path_name( const n_object *arg_path, n_object *arg_ret )
{

	// [!] : don't check whether file or dir


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_name()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	n_object *path = n_object_string_path_carboncopy( arg_path );


	n_type_int count = n_object_string_path_split( path, NULL, 0 );
	if ( count == 0 )
	{
		n_type_int cch = n_object_string_path_copy( path, arg_ret );
		n_object_string_path_terminate( arg_ret, cch );
	} else {
		n_object_string_path_split( path, arg_ret, count - 1 );
	}


	n_object_string_path_free( &path );


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return;
}

n_object*
n_object_string_path_name_new( const n_object *path )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_name_cch( path );
	n_object   *nam = n_object_string_path_new_fast( cch  );


	n_object_string_path_name( path, nam );


	return nam;
}

#define n_object_string_path_upperfolder_cch( path ) n_object_string_path_upperfolder( path, NULL )

n_type_int
n_object_string_path_upperfolder( const n_object *arg_path, n_object *arg_ret )
{

	// [!] : don't check whether a file or a folder


	if ( n_object_error( arg_path ) ) { return 0; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_upperfolder()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	n_object *path = n_object_string_path_carboncopy( arg_path );
	n_object_string_path_drivename_slash_del( path );

	n_object *name = n_object_string_path_name_new( path );
//n_posix_debug_literal( "Path : %s", N_OBJECT_STRING_PATH_PTR( path ) );
//n_posix_debug_literal( "Name : %s", N_OBJECT_STRING_PATH_PTR( name ) );

	if ( n_posix_false == n_string_is_same( N_OBJECT_STRING_PATH_PTR( path ), N_OBJECT_STRING_PATH_PTR( name ) ) )
	{
		n_posix_char *f = N_OBJECT_STRING_PATH_PTR( path );
		n_posix_char *t = N_OBJECT_STRING_PATH_PTR( name );

		n_type_int index = n_posix_strlen( f ) - n_posix_strlen( t );

		if ( index >= 1 ) { index--; }

		n_object_string_path_terminate( path, index );
	}


	if ( arg_ret != NULL )
	{
		n_type_int cch = n_object_string_path_copy( path, arg_ret );
//n_posix_debug_literal( "%s : %d", N_OBJECT_STRING_PATH_PTR( path ), cch );
		n_object_string_path_terminate( arg_ret, cch );
	}


	n_type_int cch_ret = 0;
	if ( arg_ret == NULL ) { cch_ret = path->count; }


	n_object_string_path_free( &path );
	n_object_string_path_free( &name );


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return cch_ret;
}

n_object*
n_object_string_path_upperfolder_new( const n_object *path )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

	n_type_int  cch = n_object_string_path_upperfolder_cch( path ) + 1;
	n_object   *dir = n_object_string_path_new( cch );


	n_object_string_path_upperfolder( path, dir );


	return dir;
}

// internal
n_posix_bool
n_object_string_path_short2long_is_shortname( const n_object *path, n_type_int *cch )
{

	if ( n_object_string_is_empty( path ) ) { return n_posix_false; }


	n_posix_bool ret = n_posix_false;

	n_posix_char *str = N_OBJECT_STRING_PATH_PTR( path );

	n_type_int i = 0;
	n_posix_loop
	{

		n_object_is_accessible( path, i );

		if ( str[ i ] == N_STRING_CHAR_NUL   ) { break; }
		if ( str[ i ] == N_STRING_CHAR_TILDE ) { ret = n_posix_true; }

		i++;

	}


	if ( cch != NULL ) { (*cch) = i; }


	return ret;
}

#define n_object_string_path_short2long_cch( path, ret_is_shortname ) n_object_string_path_short2long( path, NULL, ret_is_shortname )

n_type_int
n_object_string_path_short2long( const n_object *arg_path, n_object *arg_ret, n_posix_bool *ret_is_shortname )
{

	if ( n_object_string_is_empty( arg_path ) ) { return 0; }

	if ( arg_ret != NULL )
	{
		if ( n_object_error( arg_ret ) ) { return 0; }
	}


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_short2long()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	n_type_int cch = 0;


#ifdef N_POSIX_PLATFORM_WINDOWS


	if ( ret_is_shortname != NULL ) { (*ret_is_shortname) = n_posix_false; }


	// [!] : not a short name

	if ( n_posix_false == n_object_string_path_short2long_is_shortname( arg_path, &cch ) )
	{

		if ( arg_ret != NULL )
		{
			n_object_string_path_copy( arg_path, arg_ret );
			cch = 0;
		}

		return cch;
	}


	if ( n_posix_false == n_object_string_path_is_abspath( arg_path ) )
	{

		// [!] : not a path : send back

		if ( arg_ret != NULL )
		{
			n_object_string_path_copy( arg_path, arg_ret );
			cch = 0;
		}

		return cch;

	} else
	if ( n_object_string_path_is_drivename( arg_path ) )
	{

		// [!] : drive name

		if ( arg_ret != NULL )
		{
			n_object_string_path_copy( arg_path, arg_ret );
			cch = 0;
		}

		return cch;

	}


	// [!] : add a drive name

	if ( ret_is_shortname != NULL ) { (*ret_is_shortname) = n_posix_true; }

	n_object   *longname = n_object_string_path_split_new( arg_path, 0 );
	n_type_int     count = n_object_string_path_split( arg_path, NULL, 0 );

	n_type_int i = 1;
	n_posix_loop
	{

		n_object *tmpname = n_object_string_path_split_new( arg_path, i );
		n_object *shtname = n_object_string_path_make_new( longname, tmpname );

		n_object_string_path_free( &tmpname );


		// [!] : "nonnon~1" => "nonnon_win"

		WIN32_FIND_DATA f; ZeroMemory( &f, sizeof( WIN32_FIND_DATA ) );

		FindClose( FindFirstFile( N_OBJECT_STRING_PATH_PTR( shtname ), &f ) );
		n_object_string_path_free( &shtname );

		n_object *filename = n_object_string_path_set( f.cFileName );
		n_object * retname = n_object_string_path_make_new( longname, filename );

		n_object_string_path_free( &filename );
		n_object_string_path_free( &longname );

		longname = retname;

//n_posix_debug( arg_ret );


		i++;
		if ( i >= count ) { break; }
	}


	n_object_string_path_copy( longname, arg_ret );

	if ( arg_ret == NULL ) { cch = longname->count; }


	n_object_string_path_free( &longname );


#else  // #ifdef N_POSIX_PLATFORM_WINDOWS


	n_object_string_path_copy( arg_path, arg_ret );

	if ( arg_ret == NULL ) ) { cch = n_string_path_cch( arg_path ); }


#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return cch;
}

n_object*
n_object_string_path_short2long_new( const n_object *path )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_short2long_cch( path, NULL );
	n_object   *ret = n_object_string_path_new( cch );


	n_object_string_path_short2long( path, ret, NULL );


	return ret;
}

#define n_object_string_path_folder_change_fast( dir ) n_posix_chdir( N_OBJECT_STRING_PATH_PTR( dir ) );

n_posix_bool
n_object_string_path_folder_change( const n_object *path )
{

	if ( n_object_error( path ) ) { return 0; }


	if ( n_object_string_is_empty( path ) ) { return n_posix_true; }


	n_object *dir;
	if ( n_posix_stat_is_file( N_OBJECT_STRING_PATH_PTR( path ) ) )
	{
		dir = n_object_string_path_upperfolder_new( path );
		n_object_string_path_drivename_slash_add( dir );
	} else {
		dir = n_object_string_path_slash_new( path );
	}

	int ret = n_posix_chdir( N_OBJECT_STRING_PATH_PTR( dir ) );

	n_object_string_path_free( &dir );


	return ( ret != 0 );
}

n_type_int
n_object_string_path_folder_current_cch( n_posix_bool *is_shortname )
{

	// [x] : at least PATH_MAX is needed

	n_type_int cch = 1024;// PATH_MAX;
	n_type_int ret = cch;
	n_posix_loop
	{

		n_object *dir = n_object_string_path_new( cch );

		void *ptr = n_posix_getcwd( N_OBJECT_STRING_PATH_PTR( dir ), (int) cch );
		      ret = cch + n_object_string_path_short2long_cch( dir, is_shortname ); 

		n_object_string_path_free( &dir );

		if ( ptr != NULL )
		{
			break;
		} else {
			cch++;
		}

	}


	return ret;
}

void
n_object_string_path_folder_current( n_object *ret, n_type_int cch, n_posix_bool is_shortname )
{

	if ( n_object_error( ret ) ) { return; }


	n_posix_getcwd( N_OBJECT_STRING_PATH_PTR( ret ), (int) cch );

	if ( is_shortname )
	{
		n_object_string_path_short2long( ret, ret, NULL );
	}


	return;
}

n_object*
n_object_string_path_folder_current_new( void )
{

	n_posix_bool is_shortname = n_posix_false;

	n_type_int  cch = n_object_string_path_folder_current_cch( &is_shortname );
	n_object   *ret = n_object_string_path_new_fast( cch );

	n_object_string_path_folder_current( ret, cch, is_shortname );


	return ret;
}

#define n_object_string_path_ext_get_cch( path ) n_object_string_path_ext_get( path, NULL )

n_type_int
n_object_string_path_ext_get( const n_object *arg_path, n_object *arg_ret )
{

	if ( n_object_string_is_empty( arg_path ) ) { return 0; }

	if ( arg_ret != NULL )
	{
		if ( n_object_error( arg_ret ) ) { return 0; }
	}


	// [!] : not supported

	if ( arg_path == arg_ret ) { return 0; }


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_ext_get()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	// [!] : "." is DBCS safe


	n_posix_bool found = n_posix_false;

	n_type_int pos = 0;


	n_type_int i = arg_path->count - 1;
	n_posix_loop
	{ 

		if (
			( n_object_is_accessible( arg_path, i ) )
			&&
			( N_OBJECT_STRING_PATH_PTR( arg_path )[ i ] == N_STRING_CHAR_DOT )
		)
		{

			pos = i;

			found = n_posix_true;

			break;

		} else
		if ( n_object_string_path_slash_check( arg_path, i ) )
		{
			break;
		}


		if ( i == 0 ) { break; }
		i--;

	}


	n_type_int cch = 0;

	if ( arg_ret == NULL )
	{

		n_posix_char *f = &N_OBJECT_STRING_PATH_PTR( arg_path )[ pos ];

		cch = n_posix_strlen( f );

	} else
	if ( found )
	{

		n_posix_char *f = &N_OBJECT_STRING_PATH_PTR( arg_path )[ pos ];
		n_posix_char *t =  N_OBJECT_STRING_PATH_PTR( arg_ret  );

		n_posix_sprintf_literal( t, "%s%c%c", f, N_STRING_CHAR_NUL, N_STRING_CHAR_NUL );

	}


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return cch;
}

n_object*
n_object_string_path_ext_get_new( const n_object *path )
{

	n_type_int  cch = n_object_string_path_ext_get_cch( path );
	n_object   *ret = n_object_string_path_new_fast( cch );

	n_object_string_path_ext_get( path, ret );

	return ret;
}

// internal
n_posix_bool
n_object_string_path_ext_is_same( const n_object *path1, const n_object *path2 )
{

	if ( n_object_error( path1 ) ) { return n_posix_false; }
	if ( n_object_error( path2 ) ) { return n_posix_false; }


	n_object *ext1 = n_object_string_path_ext_get_new( path1 );
	n_object *ext2 = n_object_string_path_ext_get_new( path2 );
//n_posix_debug_literal( "1:%s\n2:%s", ext1, ext2 );

	n_posix_char *str1 = N_OBJECT_STRING_PATH_PTR( ext1 );
	n_posix_char *str2 = N_OBJECT_STRING_PATH_PTR( ext2 );

	n_posix_bool ret = n_string_is_same( str1, str2 );

	n_object_string_path_free( &ext1 );
	n_object_string_path_free( &ext2 );


	return ret;
}

#define N_OBJECT_STRING_PATH_EXT_SET_ADD 0
#define N_OBJECT_STRING_PATH_EXT_SET_DEL 1

#define n_object_string_path_ext_add( e, p ) n_object_string_path_ext_set_internal(    e, p, N_OBJECT_STRING_PATH_EXT_SET_ADD )
#define n_object_string_path_ext_mod( e, p ) n_object_string_path_ext_set_internal(    e, p, N_OBJECT_STRING_PATH_EXT_SET_DEL )
#define n_object_string_path_ext_del(    p ) n_object_string_path_ext_set_internal( NULL, p, N_OBJECT_STRING_PATH_EXT_SET_DEL )

// internal
void
n_object_string_path_ext_set_internal( const n_object *arg_ext, n_object *arg_path, int mode )
{

	// [Mechanism] : "ext"
	//
	//	empty : remove extension
	//	other : add/replace extension


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_ext_set_internal()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	// [!] : avoid making dot-file

	if ( n_object_string_is_empty( arg_path ) ) { return; }

	n_posix_char *path = N_OBJECT_STRING_PATH_PTR( arg_path );


	// [!] : not supported

	n_posix_char *ext = N_OBJECT_STRING_PATH_PTR( arg_ext );

	if ( ( ext != NULL )&&( ext[ 0 ] != N_STRING_CHAR_DOT ) ) { return; }


	n_type_int cch = n_posix_strlen( path );

	if ( mode == N_STRING_PATH_EXT_SET_DEL )
	{

		n_object *obj_ext = n_object_string_path_ext_get_new( arg_path );

		cch -= n_posix_strlen( N_OBJECT_STRING_PATH_PTR( obj_ext ) );

		n_object_string_path_free( &obj_ext );

	}


	if ( n_object_string_is_empty( arg_ext ) )
	{

		// [!] : n_string_path_ext_del()

		n_object_string_path_terminate( arg_path, cch );

	} else {

		n_string_path_copy( ext, &N_OBJECT_STRING_PATH_PTR( arg_path )[ cch ] );

	}


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return;
}

n_object*
n_object_string_path_ext_mod_new( const n_object *path, const n_object *ext )
{

	if ( n_object_error( path ) ) { return NULL; }
	if ( n_object_error( ext  ) ) { return NULL; }


	// [!] : you need to n_object_string_path_free() a returned variable


	// [!] : for a new name with a replacing extension
	//
	//	"C:\\name.bmp" to "C:\\name.png"


	n_type_int  cch = path->count + ext->count;
	n_object   *str = n_object_string_path_new( cch );

	n_object_string_path_copy( path, str );
	n_object_string_path_ext_mod( ext, str );


	return str;
}

#define n_object_string_path_tmpname_cch() ( ( 4 + 2 + 2 ) + 1 + ( 2 + 2 + 2 ) )

void
n_object_string_path_tmpname( n_object *str )
{

	if ( n_object_error( str ) ) { return; }


	// [Mechanism]
	//
	//	this like format is used in some locales
	//	big-to-small order is simply sortable


	int year, month, day, hour, minute, second;


	n_time_today( &year, &month, &day, &hour, &minute, &second );


	n_posix_sprintf_literal
	(
		N_OBJECT_STRING_PATH_PTR( str ),
		"%04d%02d%02d_%02d%02d%02d",
		year, month , day   ,
		hour, minute, second
	);


	return;
}

n_object*
n_object_string_path_tmpname_new( const n_object *ext )
{

	if ( n_object_error( ext ) ) { return NULL; }


	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_tmpname_cch() + ext->count;
	n_object   *str = n_object_string_path_new_fast( cch );


	n_object_string_path_tmpname( str );
	n_object_string_path_ext_set_internal( ext, str, N_STRING_PATH_EXT_SET_ADD );


	return str;
}

n_object*
n_object_string_path_cmdline2multipath( const n_object *arg_cmdline )
{

	// [!] : "C:\windows C:\nonnon" will be "C:\windows\0C:\nonnon\0\0"


	// [!] : n_object : currently unsafe

	if ( n_object_string_is_empty( arg_cmdline ) ) { return n_object_string_path_set( N_STRING_EMPTY ); }


	n_posix_char *cmdline = N_OBJECT_STRING_PATH_PTR( arg_cmdline );


	n_object *quote = NULL;
	n_object *delim = NULL;

	if ( n_string_search_simple( cmdline, N_STRING_DQUOTE ) )
	{
		quote = n_object_string_path_set( N_STRING_DQUOTE );
		delim = n_object_string_path_set( N_STRING_SPACE  );
	} else
	if ( n_string_search_simple( cmdline, N_STRING_SPACE ) )
	{

		n_type_int colon = 0;

		n_type_int i = 0;
		n_posix_loop
		{
			if ( cmdline[ i ] == N_STRING_CHAR_NUL ) { break; }

			if ( cmdline[ i ] == N_STRING_CHAR_COLON )
			{
				colon++;
				if ( colon >= 2 )
				{
					delim = n_object_string_path_set( N_STRING_SPACE );
					break;
				}
			}

			i++;
		}

	}


	n_type_int  cch = n_posix_strlen( cmdline );
	n_object   *str = n_object_string_path_set( cmdline );

	n_type_int count = n_string_parameter_count
	(
		N_OBJECT_STRING_PATH_PTR( str   ),
		N_OBJECT_STRING_PATH_PTR( delim ),
		N_OBJECT_STRING_PATH_PTR( quote )
	);
//n_posix_debug_literal( " %d ", count );

	if ( count == 0 )
	{
		n_object_string_path_free( &str   );
		n_object_string_path_free( &delim );
		n_object_string_path_free( &quote );

		return n_object_string_path_set( N_STRING_EMPTY );
	}


	n_object *ret = n_object_string_path_new( 1024 );

	n_type_int i = 0;
	n_type_int j = 0;
	n_posix_loop
	{//break;

		if ( i >= count ) { break; }

		n_object *tmp = n_object_string_path_new( cch );
		if ( tmp != NULL )
		{

			n_string_parameter
			(
				N_OBJECT_STRING_PATH_PTR( str   ),
				N_OBJECT_STRING_PATH_PTR( delim ),
				N_OBJECT_STRING_PATH_PTR( quote ),
				i,
				N_OBJECT_STRING_PATH_PTR( tmp   )
			);
n_posix_debug_literal( "Ret : %s" , N_OBJECT_STRING_PATH_PTR( tmp ) );

			j += n_posix_sprintf_literal
			(
				&N_OBJECT_STRING_PATH_PTR( ret )[ j ],
				"%s\0\0",
				N_OBJECT_STRING_PATH_PTR( tmp )
			);

			j++;

		}
		n_object_string_path_free( &tmp );

		i++;
	}


	n_object_string_path_free( &str   );
	n_object_string_path_free( &delim );
	n_object_string_path_free( &quote );


	return ret;
}

n_posix_bool
n_object_string_path_commandline_option( const n_object *arg_option, n_object *arg_path, n_posix_bool match_only )
{

	// [!] : n_object : currently unsafe

	n_posix_char *option = N_OBJECT_STRING_PATH_PTR( arg_option );
	n_posix_char *path   = N_OBJECT_STRING_PATH_PTR( arg_path   );


	// [Mechanism]
	//
	//	ret = n_posix_false : no touch
	//	ret = n_posix_true  : "option" will be removed


	n_posix_bool ret = n_posix_false;


	if (
		(
			( match_only != n_posix_false )
			&&
			( n_string_match( path, option ) )
		)
		||
		(
			( match_only == n_posix_false )
			&&
			( n_string_match( path, option ) )
			&&
			(
				( path[ n_posix_strlen( option ) ] == N_STRING_CHAR_NUL   )
				||
				( path[ n_posix_strlen( option ) ] == N_STRING_CHAR_SPACE )
			)
		)
	)
	{

		ret = n_posix_true;

		n_posix_char *tmp = n_string_path_carboncopy( path );

		n_type_int space = 0;

		n_type_int i = 0;
		n_posix_loop
		{
			if ( tmp[ n_posix_strlen( option ) + i ] == N_STRING_CHAR_NUL   )
			{
				break;
			} else
			if ( tmp[ n_posix_strlen( option ) + i ] != N_STRING_CHAR_SPACE )
			{
				break;
			} else {
				space++;
			}

			i++;
		}

		n_string_path_copy( &tmp[ n_posix_strlen( option ) + space ], path );

		n_string_path_free( tmp );

	}


	return ret;
}

n_posix_bool
n_object_string_path_rename( const n_object *f, const n_object *t )
{

	if ( n_object_error( f ) ) { return n_posix_true; }
	if ( n_object_error( t ) ) { return n_posix_true; }


	int ret = n_posix_rename( N_OBJECT_STRING_PATH_PTR( f ), N_OBJECT_STRING_PATH_PTR( t ) );


	return ( ret == -1 );
}

#define n_object_string_path_relative_cch( str ) n_object_string_path_relative( str, NULL )

n_type_int
n_object_string_path_relative( const n_object *str, n_object *ret )
{

	if ( n_object_string_is_empty( str ) ) { return 0; }

	if ( ret != NULL )
	{
		if ( n_object_error( ret ) ) { return 0; }
	}


#ifdef N_OBJECT_DEBUG

	n_object_name = n_posix_literal( "n_object_string_path_relative()" );

#endif // #ifdef N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_true;

#endif // #ifdef N_OBJECT_DEBUG


	// [!] : nothing to do : already has "./" or ".\\"

	if (
		( N_OBJECT_STRING_PATH_PTR( str )[ 0 ] == N_STRING_CHAR_DOT )
		&&
		( n_object_string_path_slash_check( str, 1 ) )
	)
	{
		return 0;
	}


	if ( n_object_string_path_is_drivename( str ) )
	{
		return 0;
	}


	n_type_int cch = 0;

	if ( ret == NULL )
	{
		// [!] : 1 == n_posix_strlen( N_STRING_DOT )
		// [!] : 1 == n_posix_strlen( N_POSIX_SLASH )

		cch = 1 + 1 + str->count;
	} else {
		cch = n_posix_sprintf_literal
		(
			N_OBJECT_STRING_PATH_PTR( ret ),
			"%s%s%s",
			N_STRING_DOT,
			N_POSIX_SLASH,
			N_OBJECT_STRING_PATH_PTR( str )
		);
	}


#ifdef N_OBJECT_DEBUG

	n_object_string_path_suppress = n_posix_false;

#endif // #ifdef N_OBJECT_DEBUG


	return cch;
}

n_object*
n_object_string_path_relative_new( const n_object *name )
{

	// [!] : you need to n_object_string_path_free() a returned variable

	n_type_int  cch = n_object_string_path_relative_cch( name );
	n_object   *str = n_object_string_path_new_fast( cch );


	n_object_string_path_relative( name, str );


	return str;
}


#endif // _H_NONNON_NEUTRAL_OBJECT_STRING_PATH

