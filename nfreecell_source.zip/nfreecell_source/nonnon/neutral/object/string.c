// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_OBJECT_STRING
#define _H_NONNON_NEUTRAL_OBJECT_STRING




#include "../object.c"
#include "../string.c"




n_posix_char*
N_OBJECT_STRING_PTR( const n_object *p )
{

	if ( n_object_error( p ) ) { return NULL; }

	return (n_posix_char*) p->ptr;
}

n_posix_bool
n_object_string_is_empty( const n_object *str )
{

	if ( n_object_error( str ) ) { return n_posix_true; }


	if ( N_OBJECT_STRING_PTR( str )[ 0 ] == N_STRING_CHAR_NUL ) { return n_posix_true; }


	return n_posix_false;
}




#endif // _H_NONNON_NEUTRAL_OBJECT_STRING


