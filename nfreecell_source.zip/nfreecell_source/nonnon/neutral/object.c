// Nonnon Neutral
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_NEUTRAL_OBJECT
#define _H_NONNON_NEUTRAL_OBJECT




#include "./posix.c"




#define N_OBJECT_DEBUG


#ifdef N_OBJECT_DEBUG

static n_posix_char *n_object_name = n_posix_literal( "" );

#endif // #ifdef N_OBJECT_DEBUG




#define N_OBJECT_PTR( p ) ( ( p )->ptr )




typedef struct {

	void       *ptr;
	n_type_int  byte;
	n_type_int  align;
	n_type_int  count;

} n_object;




#define n_object_zero( p ) n_memory_zero( p, sizeof( n_object ) )

void
n_object_debug( const n_object *p )
{

	if ( p == NULL ) { return; }


	n_posix_debug_literal
	(
		"%s\n%lld %lld %lld",
		(n_posix_char*) p->ptr,
		p->byte, p->align, p->count
	);


	return;
}

n_posix_bool
n_object_error( const n_object *p )
{

	if ( p       == NULL ) { return n_posix_true; }
	if ( p->ptr  == NULL ) { return n_posix_true; }
	if ( p->align ==   0 ) { return n_posix_true; }


	return n_posix_false;
}

n_posix_bool
n_object_is_accessible( const n_object *p, n_type_int pos )
{

	if ( n_object_error( p ) ) { return n_posix_false; }


	if ( ( pos < 0 )||( pos >= p->count ) )
	{
#ifdef N_OBJECT_DEBUG

n_posix_debug_literal( "%s : %s", n_posix_literal( "Invalid Access" ), n_object_name );

exit( 0 );

#endif // #ifdef N_OBJECT_DEBUG

		return n_posix_false;
	}


	return n_posix_true;
}

#define n_object_free(      p ) n_object_free_internal( p, n_posix_false )
#define n_object_free_fast( p ) n_object_free_internal( p, n_posix_true  )

// internal
void
n_object_free_internal( n_object **p, n_posix_bool is_fast )
{

	if (   p  == NULL ) { return; }
	if ( (*p) == NULL ) { return; }


	n_memory_free( (*p)->ptr );


	if ( is_fast == n_posix_false )
	{
		n_object_zero( (*p) );
	}


	n_memory_free( (*p) );

	(*p) = NULL;


	return;
}

n_object*
n_object_new( n_type_int count, n_type_int align, n_posix_bool zeroclear )
{

	if ( align == 0 ) { return NULL; }


	n_object *p = n_memory_new( sizeof( n_object ) );

	p->count = count;
	p->align = align;

	p->byte  = p->count * p->align;
	p->ptr   = n_memory_new( p->byte );

	if ( zeroclear ) { n_memory_zero( p->ptr, p->byte ); }


	return p;
}




#endif // _H_NONNON_NEUTRAL_OBJECT


