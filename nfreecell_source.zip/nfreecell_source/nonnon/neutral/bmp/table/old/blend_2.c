// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [x] : not faster




#ifndef _H_NONNON_NEUTRAL_BMP_TABLE_BLEND
#define _H_NONNON_NEUTRAL_BMP_TABLE_BLEND




static n_posix_bool n_bmp_table_blend_onoff = n_posix_false;


static int *n_bmp_table_blend_0_5 = NULL;
static int *n_bmp_table_blend_1_0 = NULL;
static int *n_bmp_table_blend_1_5 = NULL;
static int *n_bmp_table_blend_2_0 = NULL;
static int *n_bmp_table_blend_2_5 = NULL;
static int *n_bmp_table_blend_3_0 = NULL;
static int *n_bmp_table_blend_3_5 = NULL;
static int *n_bmp_table_blend_4_0 = NULL;
static int *n_bmp_table_blend_4_5 = NULL;
static int *n_bmp_table_blend_5_0 = NULL;
static int *n_bmp_table_blend_5_5 = NULL;
static int *n_bmp_table_blend_6_0 = NULL;
static int *n_bmp_table_blend_6_5 = NULL;
static int *n_bmp_table_blend_7_0 = NULL;
static int *n_bmp_table_blend_7_5 = NULL;
static int *n_bmp_table_blend_8_0 = NULL;
static int *n_bmp_table_blend_8_5 = NULL;
static int *n_bmp_table_blend_9_0 = NULL;
static int *n_bmp_table_blend_9_5 = NULL;




int
n_bmp_table_blend_calc( int f, int t, double blend )
{

	double d = ( f - t ) * blend;

	if ( f > t )
	{
		return f - (int) n_posix_max_double(  1.0, d );
	} else {
		return f - (int) n_posix_min_double( -1.0, d );
	}
}

void
n_bmp_table_blend_init( void )
{

	if ( n_bmp_table_blend_onoff != n_posix_false ) { return; }


	n_bmp_table_blend_0_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_1_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_1_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_2_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_2_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_3_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_3_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_4_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_4_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_5_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_5_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_6_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_6_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_7_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_7_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_8_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_8_5 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_9_0 = n_memory_new( 256 * sizeof( int ) );
	n_bmp_table_blend_9_5 = n_memory_new( 256 * sizeof( int ) );


	int i = 0;
	n_posix_loop
	{
		n_bmp_table_blend_0_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.05 );
		n_bmp_table_blend_1_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.10 );
		n_bmp_table_blend_1_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.15 );
		n_bmp_table_blend_2_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.20 );
		n_bmp_table_blend_2_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.25 );
		n_bmp_table_blend_3_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.30 );
		n_bmp_table_blend_3_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.35 );
		n_bmp_table_blend_4_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.40 );
		n_bmp_table_blend_4_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.45 );
		n_bmp_table_blend_5_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.50 );
		n_bmp_table_blend_5_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.55 );
		n_bmp_table_blend_6_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.60 );
		n_bmp_table_blend_6_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.65 );
		n_bmp_table_blend_7_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.70 );
		n_bmp_table_blend_7_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.75 );
		n_bmp_table_blend_8_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.80 );
		n_bmp_table_blend_8_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.85 );
		n_bmp_table_blend_9_0[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.90 );
		n_bmp_table_blend_9_5[ i ] = -1;//n_bmp_table_blend_calc( 0, i, 0.95 );

		i++;
		if ( i >= 256 ) { break; }
	}


	n_bmp_table_blend_onoff = n_posix_true;


	return;
}

void
n_bmp_table_blend_exit( void )
{

	if ( n_bmp_table_blend_onoff == n_posix_false ) { return; }


	n_memory_free( n_bmp_table_blend_0_5 ); n_bmp_table_blend_0_5 = NULL;
	n_memory_free( n_bmp_table_blend_1_0 ); n_bmp_table_blend_1_0 = NULL;
	n_memory_free( n_bmp_table_blend_1_5 ); n_bmp_table_blend_1_5 = NULL;
	n_memory_free( n_bmp_table_blend_2_0 ); n_bmp_table_blend_2_0 = NULL;
	n_memory_free( n_bmp_table_blend_2_5 ); n_bmp_table_blend_2_5 = NULL;
	n_memory_free( n_bmp_table_blend_3_0 ); n_bmp_table_blend_3_0 = NULL;
	n_memory_free( n_bmp_table_blend_3_5 ); n_bmp_table_blend_3_5 = NULL;
	n_memory_free( n_bmp_table_blend_4_0 ); n_bmp_table_blend_4_0 = NULL;
	n_memory_free( n_bmp_table_blend_4_5 ); n_bmp_table_blend_4_5 = NULL;
	n_memory_free( n_bmp_table_blend_5_0 ); n_bmp_table_blend_5_0 = NULL;
	n_memory_free( n_bmp_table_blend_5_5 ); n_bmp_table_blend_5_5 = NULL;
	n_memory_free( n_bmp_table_blend_6_0 ); n_bmp_table_blend_6_0 = NULL;
	n_memory_free( n_bmp_table_blend_6_5 ); n_bmp_table_blend_6_5 = NULL;
	n_memory_free( n_bmp_table_blend_7_0 ); n_bmp_table_blend_7_0 = NULL;
	n_memory_free( n_bmp_table_blend_7_5 ); n_bmp_table_blend_7_5 = NULL;
	n_memory_free( n_bmp_table_blend_8_0 ); n_bmp_table_blend_8_0 = NULL;
	n_memory_free( n_bmp_table_blend_8_5 ); n_bmp_table_blend_8_5 = NULL;
	n_memory_free( n_bmp_table_blend_9_0 ); n_bmp_table_blend_9_0 = NULL;
	n_memory_free( n_bmp_table_blend_9_5 ); n_bmp_table_blend_9_5 = NULL;


	n_bmp_table_blend_onoff = n_posix_false;


	return;
}




n_posix_inline int
n_bmp_table_blend_channel( int f, int t, double blend )
{

	// [!] : shortcut

	if ( f == t ) { return t; }

	if ( blend <= 0 ) { return f; }
	if ( blend >= 1 ) { return t; }


	if ( n_bmp_table_blend_onoff == n_posix_false )
	{
		atexit( n_bmp_table_blend_exit );
		n_bmp_table_blend_init();
	}


	if ( blend >= 0.75 ) { goto n_bmp_table_blend_channel_label_0_75; }
	if ( blend >= 0.50 ) { goto n_bmp_table_blend_channel_label_0_50; }
	if ( blend >= 0.25 ) { goto n_bmp_table_blend_channel_label_0_25; }


	if ( blend == 0.05 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_0_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_0_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.10 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_1_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_1_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.15 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_1_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_1_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.20 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_2_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_2_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	n_bmp_table_blend_channel_label_0_25 :

	if ( blend == 0.25 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_2_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_2_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.30 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_3_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_3_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.35 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_3_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_3_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.40 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_4_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_4_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.45 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_4_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_4_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	n_bmp_table_blend_channel_label_0_50 :

	if ( blend == 0.50 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_5_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_5_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.55 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_5_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_5_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.60 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_6_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_6_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.65 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_6_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_6_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.70 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_7_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_7_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	n_bmp_table_blend_channel_label_0_75 :

	if ( blend == 0.75 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_7_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_7_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.80 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_8_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_8_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.85 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_8_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_8_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.90 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_9_0[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_9_0[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}

	if ( blend == 0.95 )
	{
		int elem = abs( f - t );

		int v = n_bmp_table_blend_9_5[ elem ];
		if ( v == -1 )
		{
			n_bmp_table_blend_9_5[ elem ] = v = n_bmp_table_blend_calc( 0, elem, blend );
		}

		if ( f > t ) { return f - v; } else { return f + v; }
	}
//n_posix_debug_literal( " %f ", blend );


	// [!] : 20% faster than comment-out'ed code
	//
	//	cast to int is very important
	//
	//	logic :  5%
	//	cast  : 15%

	// [!] : don't use calculus in min()/max() when macro

	double d = ( f - t ) * blend;

	if ( f > t )
	{
		return f - (int) n_posix_max_double(  1.0, d );
	} else {
		return f - (int) n_posix_min_double( -1.0, d );
	}

/*
	double d = ( t - f ) * blend;

	if ( ( d > -1.0 )&&( d < 1.0 ) )
	{
		if ( f < t ) { d = 1; } else { d = -1; }
	}

	return f + d;
*/
}

#endif // _H_NONNON_NEUTRAL_BMP_TABLE_BLEND

